//. CREDIT JAN DI HAPUS YA PELER
// REVIEW SC INI WAJIB TAG SAYA.

// SCRIPT FIONY MD V1.0
// MY YT ; FallZx-Features 
// IG ; fallxd_781
// Base : Xeon & Danz Nano.
// Di Fix dan di Perbarui oleh FallZx

const chalk = require("chalk")
const fs = require("fs")

//aumto presence update
global.autoTyping = false //auto tying in gc (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.autoblockmorroco = true //auto block 212 (true to on, false to off)
global.autokickmorroco = true //auto kick 212 (true to on, false to off) 
global.antispam = false//auto kick spammer (true to on, false to off)


//==============APIKEY NYA BEB ================\\
global.apimiftah = 'free'||'global'||'zex' 
global.apiskizo = 'dzsyabotz'
global.apikiicode = 'Dzsyacans'
global.kiiapi = 'KC-rc8OqPJSisIr'
//=============================================\\

//===============SETTING MENU==================\\
global.thumbnail = 'https://telegra.ph/file/21006861ea49deb6977c6.png'
global.ig = 'fallxd_781'
global.fb = '𝑮𝒂 𝑷𝒖𝒏𝒚𝒂'
global.ownername = '𝑭𝒊𝒐𝒏𝒚 𝑴𝒅🍃'
global.owner = ['6285813708397'] // SETTING JUGA DI FOLDER DATABASE 
global.ownernomer = '6285813708397'
global.ytname = '𝑭𝒊𝒐𝒏𝒚 𝑴𝒅' 
global.socialm = 'GitHub: FallEzz'
global.location = 'Markas Ultramen' 
//=============================================\\
global.botname = "𝑭𝒊𝒐𝒏𝒚 𝑴𝒅⚡"
global.ownernumber = '6285813708397'
global.botnumber = '6281572768243'
global.ownername = '𝑭𝒊𝒐𝒏𝒚 𝑴𝒅 𝑶𝒘𝒏𝒆𝒓'
global.ownerNumber = ["6285813708397@s.whatsapp.net"]
global.ownerweb = ""
global.websitex = ""
global.wagc = "https://chat.whatsapp.com/LTS6qP1CGi2FlCQWnk2vwh"
global.themeemoji = '👾'
global.wm = "𝑭𝒊𝒐𝒏𝒚 𝑴𝒅| 𝟏𝟖 𝑱𝒖𝒏𝒊 ©𝟐𝟎𝟐𝟒"
global.botscript = 'SCRIPT ADA DISINI YA KAK\n Link : https://youtu.be/UfyH8EO0sPA?si=XOZJT-2MXk6DcDd2' //script link
global.packname = "Sticker By"
global.author = "\n\n\n\n\n𝑪𝒓𝒆𝒂𝒕𝒆𝒅 𝑩𝒀 𝑭𝒂𝒍𝒍𝒁𝒙\n 𝑵𝒐 𝑾𝒂  : 6285813708397"
global.creator = "6285813708397@s.whatsapp.net"
 
//if api key expire, u can generate one from here: https://beta.openai.com/account/api-keys
global.keyopenai = "pk-pIWAlRroXTOAigkWdHcYvmlmgzEQXuoMWbVAaLAVZswSRbEB"

//documents variants
global.doc1 = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.doc2 = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.doc3 = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.doc4 = 'application/zip'
global.doc5 = 'application/pdf'
global.doc6 = 'application/vnd.android.package-archive'

//Server crete panel egg biasa
global.domain = 'https://server1.joshuastore.biz.id' // Isi Domain Lu jangan kasih tanda / di akhir link
global.apikey = 'ptla_7lFLXckkwYSWzihoztfEaoxqGS5l3HLvL30wWASXyJq' // Isi Apikey Plta Lu
global.capikey = 'ptlc_ClbAnXraRfvLobzPSxgxBsdb4QlioQx1va8vvt1pKIK' // Isi Apikey Pltc Lu
//===========================//
//Server create panel egg pm2
global.apikey2 = '-' // Isi Apikey Plta Lu
global.capikey2 = '-' // Isi Apikey Pltc Lu
global.domain2 = '-' // Isi Domain Lu
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah

global.eggsnya2 = '15' // id eggs yang dipakai
global.location2 = '1' // id location
//===========================//
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // id eggs yang dipakai
global.location3 = '1' // id location
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
//===========================//

global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}

//===========================//

global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            makanancentaur: "🥗",
            makanangriffin: "🥙",
            makanankyubi: "🍗",
            makanannaga: "🍖",
            makananpet: "🥩",
            makananphonix: "🧀",
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            naga: "🐉",
            phonix: "🦅",
            kyubi: "🦊",
            griffin: "🦒",
            centaur: "🎠",
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//new
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'
global.hituet = 0
//media target
global.thum = fs.readFileSync("./Cepio1/theme/pio.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./Cepio1/theme/pio.jpg") //ur logo pic
global.err4r = fs.readFileSync("./Cepio1/theme/pio.jpg") //ur error pic
global.thumb = fs.readFileSync("./Cepio1/theme/pio.jpg") //ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//menu image maker
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

//messages
global.mess = {
wait: "*_Tunggu sebentar ya Kak♡._*",
   success: "Sukses Kak",
   on: "Sudah Aktif", 
   off: "Sudah Off",
   query: {
       text: "Teks Nya Mana Kak?",
       link: "Link Nya Mana Kak?",
   },
   error: {
       fitur: "Mohon Maaf Kak Fitur Eror Silahkan Chat Developer Bot Agar Bisa Segera Diperbaiki",
   },
   only: {
       group: "Maaf Kak Fitur Ini Hanya Bisa Digunakan Di Dalam Group",
       private: "Maaf Kak Fitur Ini Hanya Bisa Digunakan Di Dalam Private Chat",
       owner: "Maaf Kak Fitur Ini Hanya Bisa Digunakan Sama Owner Bot",
       admin: "Maaf Kak Fitur Ini Hanya Bisa Digunakan Sama Owner Bot",
       badmin: "Maaf Kak Kaya Nya Kakak Tidak Bisa Menggunakan Fitur Ini Di Karenakan Bot Bukan Admin Group",
       premium: "Maaf Kamu Belum Jadi User Premium Untuk Menjadi User Premium Silahkan Beli Ke Owner Dengan Cara Ketik .owner",
   }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
