//===============================//
// SC BUG BOT XHIRO GENERASI KE TIGA 
// BASE : RAFATHARCODE
// RECODE FULL : NOXXHIRO / XHIRO
// USAHAKAN GUNAKAN BOT SEBAIK MUNGKIN
// BUY NO ENC? SUNG KELEGRAM OWNER
// @NOXXHIRO

//GUNAKAN BOT SEWAJARNYA BIAR GAK KENA BANNED
//XHIRO BOT GENERASI 3

//INFO BOT XHIRO GEN 3
//BASE : RAFATHAR CODE
//RECODE : XHIRO
//CREDITS : NOXXHIRO
//YOUTUBE : https://www.youtube.com/@akhiroc-nine
//===============================//

//untuk ios buat kayak style button gesernya gak bakal muncul
//jadi kalian gunakan fitur command manual aja seperti dibawah ini
//.allmenu
//.mainmenu
//.produkmenu
//.downloadmenu
//.convertmenu
//.panelmenu
//.xhiropanel
//.installpanelmenu
//.kudetapanelmenu
//.domainmenu
//.paptt
//.cuaca
//.pushkontakmenu
//.grupmenu
//.bugmenu
//.bugmenuvip
//.bugmenuketiga
//.bugkhususpoco
//.murbugxhiro
//.murbugxhirocuy
//.buggroupmenu
//.bugbetaaa
//.bugwabeta
//.bug-wa-beta
//.toolsddos
//.ddosmenu
//.doxingmenu
//.infobot
//.toolsddosprivat
//.pay
//.infogempa
//.ownermenu

//misal mau riview kasih credit gua dan tag youtube gua begoo
//credits noxxhiro
//https://www.youtube.com/@akhiroc-nine