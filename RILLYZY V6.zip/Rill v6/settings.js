global.prefa = ['','!','.',',','🐤','🗿']

global.owner = ['6285840351569']
global.botname = 'Rill Bot'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "Rill Official"
global.sticker2 = "🌜"